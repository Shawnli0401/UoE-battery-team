these data is an example for the lib 
https://impedancepy.readthedocs.io/en/latest/getting-started.html

to estimate resistance and build circuit model from impedance measurements 
